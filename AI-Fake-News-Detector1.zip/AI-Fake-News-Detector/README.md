# AI-Fake-News-Detector
This project helps us to detect that either the news is real or fake
